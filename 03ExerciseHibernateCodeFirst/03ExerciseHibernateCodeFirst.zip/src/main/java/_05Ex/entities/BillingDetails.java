package _05Ex.entities;

public interface BillingDetails {
    String getNumber();
    User getOwner();
}
