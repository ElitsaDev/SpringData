package _06ExBonus.enums;

public enum RoundPhase {
    GROUPS,
    LEAGUE,
    ROUND_OF_8,
    QUARTER_FINALS,
    SEMI_FINALS,
    FINAL
}
