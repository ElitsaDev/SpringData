package com.exercise.enums;

public enum AgeRestriction {
    MINOR,
    TEEN ,
    ADULT;
}
