package com.exercise.enums;

public enum EditionType {
    NORMAL,
    PROMO ,
    GOLD;
}
