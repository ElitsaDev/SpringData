package com.exercise.servises;

import com.exercise.entities.Author;

public interface AuthorService {
    Author getRandomAuthor();
}
