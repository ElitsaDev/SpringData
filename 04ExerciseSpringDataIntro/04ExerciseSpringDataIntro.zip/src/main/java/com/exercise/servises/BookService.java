package com.exercise.servises;

import org.springframework.stereotype.Service;

@Service
public class BookService {
    public void insert() {
    }
}
